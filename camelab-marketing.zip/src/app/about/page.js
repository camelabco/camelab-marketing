import Header from '../component/header'
export default function About() {
  return (
    <>
        <Header />
        <h1>About US</h1>
    </>
  );
}
