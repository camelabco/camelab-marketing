import Header from '../component/header'
export default function Contact() {
  return (
    <>
        <Header />
        <h1>contact</h1>
    </>
  );
}
